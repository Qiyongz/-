// 4. 删除联系人
module.exports = function (param) {
  // 输入 linkId	整形	要删除的联系人Id
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data": "购票成功"
  }
}
