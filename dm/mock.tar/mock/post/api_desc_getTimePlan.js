//2. 查询分类接口
// 本接口用于商品搜索页查询商品分类列表
module.exports = function (param) {
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data|1-4": [
      {
       'id|+1': 1,
        title: "abckde",
        'itemId|+1': 1,
        startTime: '@datetime()',
        endTime: "2017-12-26",
        cinemaId: 25
      }
    ]
  }
}
 