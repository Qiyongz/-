//2. 查询分类接口
// 本接口用于商品搜索页查询商品分类列表
module.exports = function (param) {
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data|3": [
      {
        id: "@id",
        itemName: "小柯音乐剧未来三部曲之《我变了，我没变》",
        areaId: "",
        areaName: "",
        address: "",
        startDate: "2018年1月8日 11:56",
        endDate: "",
        'imgUrl|1': ["/static/img/img_17.0eca905.png", "/static/img/img_16.5cf093c.png", "/static/img/img_18.853a561.png"],
        minPrice: "180"
      }
    ]
  }
}
