//2. 查询分类接口
// 本接口用于商品搜索页查询商品分类列表
module.exports = function (param) {
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data|1-6": [
      {
        'itemId|+1': 12,
        'userId|+1': 12,
        imgUrl: "/static/img/img_01.21e9c6f.png",
        'score|+1': 1.6,
        content: "喜剧风格引发深刻思考，精采!精采!精采!非常值得一看!",
        createdTime: "2017年12月23日",
      }
    ]
  }
}
 