// 2. 修改用户信息
// 本接口用于修改个人信息页的用户信息
module.exports = function (param) {
  // 根据修改的用户信息的内容来改变自己的用户 信息
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data": "修改成功"
  }
}
