//2. 查询分类接口
// 本接口用于商品搜索页查询商品分类列表
module.exports = function (param) {
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data|1-6": [
      {
        'id|1-6': 1,
        'scheduleId|1-6': 20,
        'price|+10': 80,
        'isHaveSeat|0-1': 0
      }
    ]
  }
}
 