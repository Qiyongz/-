//2. 查询分类接口
// 本接口用于商品搜索页查询商品分类列表
module.exports = function (param) {
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data":
      {
        seatArray: [
          "_____aaaaa_____aaaa_____aaaa____",
          "___ccccccc____cccccc____ccccc___",
          "__aaaaaaaa___aaaaaaaa___aaaaaa__",
          "__cccccccc__bbbbbbbbbb__ccccccc_",
          "_aaccccccc_bbbbbbbbbbbb_ccccccca",
          "_aaccccccc_bbbbbbbbbbbb_ccccccca",
          "________________________________",
          "_aaaaaaaaa__cccccccccc__aaaaaaaa",
          "_aaaaaaaaa__cccccccccc__aaaaaaaa",
          "__aaaaaaaa___aaaaaaaa___aaaaaaa_",
          "__aaaaaaaa___aaaaaaaa___aaaaaaa_"
        ]
      }
  }
}
