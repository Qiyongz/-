// 1. 查询市区API接口
module.exports = function () {
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data|7": [
      {
        "id|+1": 1,
        "name|+1": [
          "北京",
          "上海",
          "深圳",
          "杭州",
          "广州",
          "成都",
          "西安"
        ]
      }
    ]
  }
}

/* {
  "success": '',
  "errorCode": '0000',
  "msg": '',
} */