//2. 查询分类接口
// 本接口用于商品搜索页查询商品分类列表
module.exports = function (param) { 
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data|1-6": [
      {
        'id|+1': 12,
        itemName: "大型多媒体励志互动儿童剧《爱丽丝梦游仙境》（11月）",
        'areaId|+1': 1,
        areaName: "北京",
        address: "国家大剧院-北京",
        startDate: "2017-09-19",
        endDate: "2017-09-19",
        imgUrl: "/static/img/img_01.21e9c6f.png",
        'minPrice|+1': 120
      }
    ]
  }
}
 