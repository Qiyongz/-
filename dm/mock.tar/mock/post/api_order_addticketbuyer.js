// 2. 添加常用购票人
// 本接口用于添加常用购票人
module.exports = function (param) {
  /* name	字符串	用户姓名
idCard	字符串	身份证号码
cardType	字符串	卡类型(0:身份证,1:军官证)
 */
  return {
    success: '',
    errorCode: '0000',
    msg: '',
    "data": "添加成功"
  }
}
